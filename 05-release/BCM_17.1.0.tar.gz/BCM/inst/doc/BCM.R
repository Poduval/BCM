## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
packageDescription("BCM")
news(package = "BCM")

library(BCM)
getNamespaceExports("BCM")

?bcm_programs
?bcm_papers
?bcm_results
?bcmdata

bcm_programs()
bcm_papers()
bcm_results()

