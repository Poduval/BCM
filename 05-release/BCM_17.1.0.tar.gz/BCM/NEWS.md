
# Changes in Package Version 17.1.1

* Replaced existing functions with dplyr operations
* Added dplyr as dependency
* Added `bcm_results()`

# Changes in Package Version 17.1.0 (First version)

* Added `bcm_programs`
* Added `bcm_papers`
